from torchvision import transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
import os

def create_dataloaders(train_data: str,
                       test_data: str,
                       train_transform: transforms.Compose,
                       test_transform: transforms.Compose,
                       batch_size: int=32,
                       target_transform=None):
   """Required arguments train_data, test_data, train_transform, test_transform""" 
   NUM_WORKER = os.cpu_count()

   train_data = ImageFolder(root=train_data,
                         transform=train_transform,
                         target_transform=target_transform)

   test_data = ImageFolder(root=test_data,
                        transform=test_transform,
                        target_transform=target_transform)

   train_dataloader = DataLoader(
                       dataset=train_data,
                       batch_size=batch_size,
                       shuffle=True,
                       num_workers=NUM_WORKER,
                       pin_memory=True
                   )

   test_dataloader = DataLoader(
                       dataset=test_data,
                       batch_size=batch_size,
                       shuffle=False,
                       num_workers=NUM_WORKER,
                       pin_memory=True
                   )

   class_names = train_data.classes
   return train_dataloader, test_dataloader, class_names
