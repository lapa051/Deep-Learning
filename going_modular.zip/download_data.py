import requests
from pathlib import Path
import zipfile as zipf
import os

def download_data(url: str, dir_name: str):
    """Required arguments: a url for get the data and a dir name to store data"""
    data_folder = Path(dir_name)
    data_folder.mkdir(parents=True, exist_ok=True)

    path_for_down = data_folder / Path(url).name

    with requests.get(url, stream=True) as respones:
        if respones.status_code == 200:
            with open(path_for_down, "wb") as file:
                for bytes_chunk in respones.iter_content(chunk_size=8192):
                    file.write(bytes_chunk)

            print("File donwloaded successfully.")
        else:
            print("Can't get data or url wrong!")

    if str(path_for_down).endswith(".zip"):
        try:
            with zipf.ZipFile(path_for_down, "r") as zf:
                zf.extractall(data_folder)
            print("Successfully extracted")

        except Exception as e:
            print(f"Error: {e}")

        os.remove(path_for_down)
