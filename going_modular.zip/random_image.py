from PIL import Image
import random
import matplotlib.pyplot as plt
import os

def show_image(dir_path: str,
             sample: int=1):

    """Required parameters a directory path and num samples in int (max 4)"""
    if not os.path.exists(dir_path):
         return "Folder path doesn't exists!"

    sample = 4 if sample > 4 else (2 if sample < 1 else sample)
    
    image_paths = Path(dir_path).glob("*/*.jpg")

    images = list(image_paths) 

    random_images = random.sample(images, k=sample)
    
    for i, image in enumerate(random_images):
    
        img = Image.open(image)
        img_label = image.parent.stem
        
        plt.figure(figsize=(6,4))
        plt.subplot(1, sample, i+1)
        plt.imshow(img)
        plt.title(img_label)
        plt.axis("off")
        plt.show()


show_image("/content/Food5/test")
