import torch

def train_step(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          optimizer: torch.optim.Optimizer,
          train_dataloader: torch.utils.data.DataLoader,
          device):
    
    train_loss, train_acc = 0, 0

    model.train()   
    for batch, (X_train, y_train) in enumerate(train_dataloader):

        X, y = X_train.to(device), y_train.to(device)

        y_pred_logits = model(X)
        loss = loss_func(y_pred_logits, y)
       
        train_acc += (y_pred_logits.argmax(dim=1) == y).sum().item() / len(y_pred_logits)
        train_loss += loss.item()

        optimizer.zero_grad()

        loss.backward()

        optimizer.step()

        
    train_loss /= len(train_dataloader)
    train_acc /= len(train_dataloader)

    return train_loss, train_acc
