import torch
from typing import Tuple, List

def true_pred(
    model: torch.nn.Module,
    dataloader: torch.utils.data.DataLoader,
    device: torch.device) -> Tuple[List[int], List[int], List[int]]:

    y_true = []  # Storing the real image label
    y_preds = []  # Storing the predicted image label
    y_pred_prob = []  # Storing the prediction probability

    model.eval()  # Set model to evaluation mode to turn of gradient decent and backpropagation
    with torch.inference_mode():
        for image, label in dataloader:
            image, label = image.to(device), label.to(device)
            y_pred_logits = model(image)
            y_pred = y_pred_logits.argmax(dim=1)
            y_prob_tensor, _ = torch.softmax(y_pred_logits, dim=1).max(dim=1)
            y_true.append(label)
            y_preds.append(y_pred)
            y_pred_prob.append(y_prob_tensor)

    y_true, y_preds, y_pred_prob = (
        torch.cat(y_true).type(torch.int32).cpu().numpy(),
        torch.cat(y_preds).type(torch.int32).cpu().numpy(),
        torch.round(torch.cat(y_pred_prob)*100).type(torch.int32).cpu().numpy(),
    )

    return y_true, y_preds, y_pred_prob