import torch
from typing import Tuple, List

def true_pred(model: torch.nn.Module,
              dataloader: torch.utils.data.DataLoader,
              device: torch.device) -> Tuple[List[float], List[float], List[float]]:

    y_true = [] # Storing the real image label
    y_preds = [] # Storing the predicted image label
    y_pred_prob = [] # Storing the prediction probability

    model.eval() # Set model to evaluation mode to turn of gradient decent and backpropagation
    with torch.inference_mode():
        for image, label in dataloader:
            image, label = image.to(device), label.to(device)
            y_pred_logits = model(image)
            y_pred = y_pred_logits.argmax(dim=1)
            y_prob_tensor = torch.softmax(y_pred_logits, dim=1).max()
            y_true.append(label)
            y_preds.append(y_pred)
            y_pred_prob.append(y_prob_tensor)

    y_true, y_preds, y_pred_prob = torch.cat(y_true), torch.cat(y_preds), torch.cat(y_pred_prob)

    return y_true.cpu().numpy(), y_preds.cpu().numpy(), y_pred_prob.cpu().numpy().round(2)
