import torch

def test_step(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          test_dataloader: torch.utils.data.DataLoader,
          device):

    test_loss, test_acc = 0, 0

    model.eval()
    with torch.inference_mode():

        for X_test, y_test in test_dataloader:

            X, y = X_test.to(device), y_test.to(device)

            y_pred_logits = model(X)

            test_loss += loss_func(y_pred_logits, y).item()

            test_acc += (y_pred_logits.argmax(dim=1) == y).sum().item() / len(y_pred_logits)

    test_loss /= len(test_dataloader)
    test_acc /= len(test_dataloader)

    return test_loss, test_acc
