from torchvision.datasets import ImageFolder
from torchvision import transforms
from torch.utils.data import DataLoader
import os
from typing import Tuple, Dict

def get_normalize(data_path: str,
                  batch_size: int=32,
                  image_size: Tuple[int, int]=(224,224),
                  transform: transforms.Compose=None) -> Dict[str, list]:
    """Calculates the mean and standard deviation for image normalization.

    Args:
        data_path (str): The path to the dataset directory.
        batch_size (int, optional): The number of images per batch for the DataLoader. Defaults to 32.
        image_size (Tuple[int, int], optional): The target size for resizing images (height, width). Defaults to (224, 224).
        transform (transforms.Compose, optional): A custom torchvision transform to apply to images.
                                                 If None, a default transform (Resize and ToTensor) is used. Defaults to None.

    Returns:
        Dict[str, list]: A dictionary containing 'mean' and 'std' lists of floats,
                         representing the calculated average mean and standard deviation per channel.
    """
    # Set a transform for images
    if transform is None:
        transform = transforms.Compose([transforms.Resize(image_size),
                                    transforms.ToTensor()])

    # Make image to iterable with ImageFolder
    image_data = ImageFolder(data_path,
                             transform=transform,
                             target_transform=None)

    # Make dataloader
    image_dataloader = DataLoader(dataset=image_data,
                                 batch_size=batch_size,
                                 shuffle=False,
                                 num_workers=os.cpu_count())
    avg_mean = 0
    avg_std = 0

    total_image = 0

    for image, _ in image_dataloader:
        # Get the image batch size
        batch_size = image.size(0)
        # Convert image height and weight to flatten
        all_image = image.view(batch_size, image.size(1), -1)
        # Calculate and sum the mean of per color channel
        avg_mean += all_image.mean(2).sum(0)
        # Calculate and sum the std of per color channel
        avg_std += all_image.std(2).sum(0)
        # Add batch to total image
        total_image += batch_size

    # Calculate the average mean and std by dividing total image
    avg_mean /= total_image
    avg_std /= total_image

    # convert tensors to normal integers value
    normalize = {"mean": [round(m.item(), 4) for m in avg_mean],
                 "std": [round(s.item(), 4) for s in avg_std]
            }

    return normalize
