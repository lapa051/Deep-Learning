import torch
from tqdm.auto import tqdm

def train_step(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          optimizer: torch.optim.Optimizer,
          train_dataloader: torch.utils.data.DataLoader,
          device):
    
    train_loss, train_acc = 0, 0

    model.train()   
    for batch, (X_train, y_train) in enumerate(train_dataloader):

        X, y = X_train.to(device), y_train.to(device)

        y_pred_logits = model(X)
        loss = loss_func(y_pred_logits, y)
       
        train_acc += (y_pred_logits.argmax(dim=1) == y).sum().item() / len(y_pred_logits)
        train_loss += loss.item()

        optimizer.zero_grad()

        loss.backward()

        optimizer.step()

        
    train_loss /= len(train_dataloader)
    train_acc /= len(train_dataloader)

    return train_loss, train_acc
    
def test_step(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          test_dataloader: torch.utils.data.DataLoader,
          device):

    test_loss, test_acc = 0, 0

    model.eval()
    with torch.inference_mode():

        for X_test, y_test in test_dataloader:

            X, y = X_test.to(device), y_test.to(device)

            y_pred_logits = model(X)

            test_loss += loss_func(y_pred_logits, y).item()

            test_acc += (y_pred_logits.argmax(dim=1) == y).sum().item() / len(y_pred_logits)

    test_loss /= len(test_dataloader)
    test_acc /= len(test_dataloader)

    return test_loss, test_acc
    
def train(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          optimizer: torch.optim.Optimizer,
          train_dataloader: torch.utils.data.DataLoader,
          test_dataloader: torch.utils.data.DataLoader,
          device,
          epochs: int=10,
          print_step: int=1):

    model_results = {"epochs": [],
                    "train_loss": [],
                    "train_acc": [],
                    "test_loss": [],
                    "test_acc": []
                    }

    for epoch in tqdm(range(epochs)):

        print(f"Epoch: {epoch+1}\n")

        train_loss, train_acc = train_step(model=model,
                                           loss_fn=loss_fn,
                                           optimizer=optimizer,
                                           train_dataloader=train_dataloader,
                                           device=device)

        test_loss, test_acc = test_step(model=model,
                                       loss_fn=loss_fn,
                                       test_dataloader=test_dataloader,
                                       device=device)

        if (epoch+1) % print_step == 0:
            print(f"\nTrain loss: {train_loss:.4f} | Train acc: {train_acc:.4f}")
            print(f"Test loss: {test_loss:.4f} | Test acc: {test_acc:.4f}\n")

        model_results["epochs"].append(epoch)
        model_results["train_loss"].append(train_loss)
        model_results["train_acc"].append(train_acc)
        model_results["test_loss"].append(test_loss)
        model_results["test_acc"].append(test_acc)

    return model_results
