import torch

def engine(model: torch.nn.Module,
          loss_fn: torch.nn.Module,
          optimizer: torch.optim.Optimizer,
          train_dataloader: torch.utils.data.DataLoader,
          test_dataloader: torch.utils.data.DataLoader,
          device,
          epochs: int=10,
          print_step: int=1):

    model_results = {"epochs": [],
                    "train_loss": [],
                    "train_acc": [],
                    "test_loss": [],
                    "test_acc": []
                    }

    for epoch in range(epochs):

        print(f"Epoch: {epoch+1}\n")

        train_loss, train_acc = train_step(model=model,
                                           loss_fn=loss_fn,
                                           optimizer=optimizer,
                                           train_dataloader=train_dataloader,
                                           device=device)

        test_loss, test_acc = test_step(model=model,
                                       loss_fn=loss_fn,
                                       test_dataloader=test_dataloader,
                                       device=device)

        if (epoch+1) % print_step == 0:
            print(f"\nTrain loss: {train_loss:.4f} | Train acc: {train_acc:.4f}")
            print(f"Test loss: {test_loss:.4f} | Test acc: {test_acc:.4f}\n")

        model_results["epochs"].append(epoch)
        model_results["train_loss"].append(train_loss)
        model_results["train_acc"].append(train_acc)
        model_results["test_loss"].append(test_loss)
        model_results["test_acc"].append(test_acc)

    return model_results
