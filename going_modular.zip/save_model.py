from pathlib import Path
import json
import shutil
import torch

def save_model(model: torch.nn.Module,
               model_name: str,
               add_extra_details: dict=None,
               make_archive_file=False):

    model_dir = Path("Models")
    model_dir.mkdir(parents=True, exist_ok=True)

    model_save_path = model_dir / f"{model_name}.pth"

    try:
        model_weights = model.state_dict()
        torch.save(obj=model_weights, f=model_save_path)
    
        if add_extra_details is not None:
            extra = model_dir / "extra.json"
            with open(extra, 'w') as file:
                json.dump(add_extra_details, file, indent=4)

        print("Model saved successfully")
    except Exception as e:
        print(e)
        print("Model couldn't saved!")

    if make_archive_file:
        file_name = model_name
        shutil.make_archive(file_name, "zip", model_dir)
        print("Successfully archive!")
