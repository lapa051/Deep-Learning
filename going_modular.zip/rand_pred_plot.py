import torch
import random
from PIL import Image
from torchvision import transforms
import matplotlib.pyplot as plt
from pathlib import Path

def predict(model: torch.nn.Module,
            image_dir: str,
            class_names: list,
            transform: transforms.Compose,
            device: torch.device,
            n_sample: int=1):

    """Required parameters model, image directory, class names, transform, device, and n sample"""

    # Get the single image paths from whole image folder
    image_paths = list(Path(image_dir).glob("*/*.jpg"))
    # Select randomly image by given n sample
    random_images = random.sample(image_paths, k=n_sample)
    # Create a list to transformed image
    transform_images = []
    # Transform every selected random image
    for image_path in random_images: # Iterating over random image paths
        img = Image.open(image_path).convert('RGB') # Openning every single image
        transform_images.append(transform(img).unsqueeze(dim=0)) # Transform image and add to list after unsqueezing extra dimensions

    # Set the model to evaluate mode to stop gradient decent and backpropagation
    model.eval()
    with torch.inference_mode():
        for i in range(n_sample):
            # Make predictions with model on those random images
            pred_logits = model(transform_images[i].to(device))
            # Get the label of image
            pred = pred_logits.argmax(dim=1)
            # Plot the image with pred label name and actual image label name
            plt.figure(figsize=(6, 4))
            plt.subplot(1, n_sample, i+1)
            plt.imshow(Image.open(random_images[i])) # Use random_images[i] for original image path
            plt.title(f"OG: {random_images[i].parent.stem} | P: {class_names[pred]} | pb: {torch.softmax(pred_logits, dim=1).max():.2f}")
            plt.axis('off')
    plt.show()
